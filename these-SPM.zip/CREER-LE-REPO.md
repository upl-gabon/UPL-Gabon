# Créer le dépôt `these` en 5 minutes (puis SUPPRIMER ce fichier)

1. Sur GitHub : **New repository** → nom `these` → **Private** → créer (sans README).
2. Dézipper cette archive, puis dans le dossier :
   ```bash
   git init -b main
   git add .
   git commit -m "these: depot autonome initial (site + jury + reprise)"
   git remote add origin https://github.com/<compte>/these.git
   git push -u origin main
   ```
   *(Remplacer `<compte>` ; avec `gh` : `gh repo create these --private --source=. --push`.)*
3. Activer l'aperçu : Settings → **Pages** → Source `main` / `/ (root)`.
   Adresse : `https://<compte>.github.io/these/`.
4. Vérifier : `npm test` → 9/9 verts. Ouvrir le site : zone privée (`noindex` + `robots.txt`).
5. **Supprimer ce fichier** (`git rm CREER-LE-REPO.md`), commiter, pusher.

Ensuite : travailler par branches (`these: …`), PR vers `main`,
et **mettre à jour `REPRISE.md` à chaque fin de message** (protocole § 0).
