# UPL — Site institutionnel

**Lire d’abord :** [`HANDOVER.md`](./HANDOVER.md)

## En 30 secondes

- Institution : Université Privée de Libreville  
- Offre publique : **Executive MBA** seulement  
- Mail : `contact@upl-gabon.com`  
- Charte : bleu `#0B2A5B` / or `#C9A227`  
- Stack : HTML statique · Netlify · GitHub privé UPL  

## Commandes

```bash
npm test          # stabilité (obligatoire)
npm run serve     # http://127.0.0.1:5173
```

## GitHub

Compte / org avec **`contact@upl-gabon.com`** — guide : `docs/03_CREATE_GITHUB_NOW.md`

## Ne pas

- Publier des filières « projet »  
- Supprimer Netlify avant validation finale  
- Afficher le numéro perso de Calvin en contact permanent  

© Université Privée de Libreville
